package com.example.weighttrackerniyatishetty;

import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.database.Cursor;
import android.content.ContentValues;
import android.util.Log;


public class DatabaseHelper extends SQLiteOpenHelper {

    //Database name
    private static final String DATABASE_NAME = "WeightTracker.db";

    //Database version - start with 1.
    private static final int DATABASE_VERSION = 2;

    //User Table for storing login information
    public static final String USERS_TABLE = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String TARGET_WEIGHT = "target_weight";


    public static final String TABLE_WEIGHT = "weights_entries";
    public static final String COLUMN_WEIGHT_ID = "id";
    public static final String COLUMN_WEIGHT_USERNAME = "username";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_DATE = "date";

    private static final String CREATE_USERS_TABLE = "CREATE TABLE " +
            USERS_TABLE + " (" +
            COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_USERNAME + " TEXT UNIQUE, " +
            COLUMN_PASSWORD + " TEXT, " +
            TARGET_WEIGHT + " REAL )";

    private static final String CREATE_WEIGHT_TABLE = "CREATE TABLE " +
            TABLE_WEIGHT + " (" +
            COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_WEIGHT_USERNAME + " TEXT, " +
            COLUMN_WEIGHT + " REAL, " +
            COLUMN_DATE + " TEXT )";

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Create the database(s)
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("DatabaseHelper", "Creating two tables");
        db.execSQL(CREATE_USERS_TABLE); // creating users table.
        db.execSQL(CREATE_WEIGHT_TABLE); // creating weights table.
    }

    /**
     * Upgrade the database(s)
     * @param db The database.
     * @param oldVer The old database version.
     * @param newVer The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
        db.execSQL("DROP TABLE IF EXISTS " + USERS_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);

        onCreate(db); // create users table.
    }

    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Look up the database for user
        Cursor cursor = db.query(USERS_TABLE, null, COLUMN_USERNAME + "=?",
                new String[]{username}, null, null,null);
        // Check if the count is greater than 0
        if (cursor.getCount() > 0) {
            cursor.close();
            // The user exists
            return false;
        }

        cursor.close();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_PASSWORD, password);
        long result = db.insert(USERS_TABLE, null, contentValues);
        return result != -1;
    }

    public boolean loginUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(USERS_TABLE, null,
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password}, null, null,null);

        boolean result = cursor.getCount() > 0; // check if entry added to database
        Log.d("DatabaseHelper", "Login user: " + username + " returned: " + result);
        cursor.close(); // Close the cursor
        return result;
    }

    public double getTargetWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT target_weight FROM users where username =?",
                new String[]{username});
        if (cursor.moveToFirst()) {
            double target = cursor.getDouble(0);
            cursor.close();
            return target;
        }

        cursor.close();
        return 0;

    }

    public boolean setTargetWeight(String username, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("target_weight", weight);

        int rows = db.update("users", values,
                "username =?", new String[]{username});
        return  rows > 0;
    }

    public boolean insertWeight(String username, double weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_USERNAME, username);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_DATE, date);
        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;

    }
    public boolean insertWeight(String username, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_USERNAME, username);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_DATE, System.currentTimeMillis());
        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;

    }

    public Cursor getUserWeights(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_WEIGHT, null,
                COLUMN_WEIGHT_USERNAME + "=?",
                new String[]{username}, null, null, COLUMN_DATE + " DESC");
    }



}
