package com.example.weighttrackerniyatishetty;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;
import java.util.Map;

public class DashboardActivity extends AppCompatActivity {
    private Button buttonAddWeight, buttonTargetWeight;
    private TextView textViewCurrentWeight, textViewTargetWeight;
    private DatabaseHelper dbHelper;
    private String userName;

    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);

        setContentView(R.layout.activity_dashboard);

        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonTargetWeight = findViewById(R.id.buttonTargetWeight);

        textViewCurrentWeight = findViewById(R.id.textViewCurrentWeight);
        textViewTargetWeight = findViewById(R.id.textViewTargetWeight);

        dbHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
        userName = intent.getStringExtra("username");
        if (userName == null) {
            Toast.makeText(this, "User not Found!!!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadCurrentWeight();
        loadTargetWeight();

        buttonAddWeight.setOnClickListener(v-> {
            Intent intent1 = new Intent(DashboardActivity.this,
                    AddWeightActivity.class);
            intent1.putExtra("username", userName);
            startActivity(intent1);
        });

        buttonTargetWeight.setOnClickListener(v-> {
            Intent intent2 = new Intent(DashboardActivity.this,
                    TargetWeightActivity.class);
            intent2.putExtra("username", userName);
            startActivity(intent2);
        });


        LineChart lineChart = findViewById(R.id.lineChart);
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        String username = getIntent().getStringExtra("username");

        Cursor cursor = dbHelper.getUserWeights(username);
        ArrayList<Entry> weightEntries = new ArrayList<>();
        ArrayList<String> dateLabels = new ArrayList<>();
        int index = 0;

        while (cursor.moveToNext()) {
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
            String strDate = cursor.getString(cursor.getColumnIndexOrThrow("date"));

            weightEntries.add(new Entry(index, (float) weight));
            dateLabels.add(strDate);
            index++;
        }

        cursor.close();

        LineDataSet lineDataSet = new LineDataSet(weightEntries, "Weight progress");
        lineDataSet.setLineWidth(2f);
        lineDataSet.setCircleRadius(4f);
        lineDataSet.setColor(getColor(R.color.purple_500));
        lineDataSet.setValueTextSize(10f);

        LineData lineData = new LineData(lineDataSet);
        lineChart.setData(lineData);
        lineChart.getDescription().setEnabled(false);
        lineChart.getAxisRight().setEnabled(false);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                if (index >= 0 && index < dateLabels.size()) {
                    return dateLabels.get(index);
                }
                return "";
            }
        });

        lineChart.invalidate();

    }

    private void loadCurrentWeight() {
        Cursor cursor = dbHelper.getUserWeights(userName);
        if (cursor != null && cursor.moveToFirst()) {
            double latestWeight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
            textViewCurrentWeight.setText("Current Weight: " + latestWeight + " lbs");
        }
        else {
            textViewCurrentWeight.setText(("Current Weight: Not Available!!!!"));
        }
        if (cursor != null) {
            cursor.close();
        }
    }
    private void loadTargetWeight() {
        double target = dbHelper.getTargetWeight(userName);
        if (target > 0 ) {
            textViewTargetWeight.setText("Target Weight: " + target + " lbs.");
        }
        else {
            textViewTargetWeight.setText("Target Weight: Not Set!!! ");

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCurrentWeight();
        loadTargetWeight();
    }


}
