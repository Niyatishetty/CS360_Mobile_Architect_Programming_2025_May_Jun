package com.example.weighttrackerniyatishetty;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TargetWeightActivity extends AppCompatActivity {

    private EditText editTextTargetWeight;
    private Button buttonSaveTargetWeight, buttonCancelTargetWeight;
    private DatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_target_weight);

        editTextTargetWeight = findViewById(R.id.editTextTargetWeight);
        buttonSaveTargetWeight = findViewById(R.id.buttonSaveTargetWeight);
        buttonCancelTargetWeight = findViewById(R.id.buttonCancelTargetWeight);
        dbHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        if (username == null) {
            Toast.makeText(this, "User Not Found!!!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        buttonSaveTargetWeight.setOnClickListener(v-> saveTargetWeight());
        buttonCancelTargetWeight.setOnClickListener(v->finish());

    }

    private void saveTargetWeight() {
        String weightInput = editTextTargetWeight.getText().toString().trim();

        if (weightInput.isEmpty()) {
            Toast.makeText(this, "Please Enter a Target Weight!!!",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double targetWeight = Double.parseDouble(weightInput);
            boolean success = dbHelper.setTargetWeight( username, targetWeight);

            if (success) {
                Toast.makeText(this, "Target Weight Saved.", Toast.LENGTH_SHORT).show();
                finish();
            }
            else {
                Toast.makeText(this,
                        "Failed to Save Target Weight", Toast.LENGTH_SHORT).show();

            }

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid Weight Format!!!", Toast.LENGTH_SHORT).show();
        }
    }

}
