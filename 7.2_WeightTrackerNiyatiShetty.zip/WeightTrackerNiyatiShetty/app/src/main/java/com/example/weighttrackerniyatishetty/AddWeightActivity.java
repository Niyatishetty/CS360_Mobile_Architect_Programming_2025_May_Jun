package com.example.weighttrackerniyatishetty;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddWeightActivity extends AppCompatActivity {

    private EditText editTextWeight;
    private Button buttonSaveWeight, buttonCancelWeight;
    private DatabaseHelper dbHelper;

    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_weight);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        buttonCancelWeight = findViewById(R.id.buttonCancelWeight);

        dbHelper = new DatabaseHelper(this);
        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        if (username == null ) {
            Toast.makeText(this, "User Not Found!!!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        buttonSaveWeight.setOnClickListener(v -> saveWeight());

        buttonCancelWeight.setOnClickListener(v-> {
            finish();
        });
    }


    private void saveWeight() {
        String weightInput = editTextWeight.getText().toString().trim();

        if (weightInput.isEmpty()) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            double weight = Double.parseDouble(weightInput);

            boolean success = dbHelper.insertWeight(username, weight);
            if (success)  {
                Toast.makeText(this,
                        "Weight saved successfully !!!", Toast.LENGTH_SHORT).show();
                finish();
            }
            else {
                Toast.makeText(this,
                        "Failed to Save Weight", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight format", Toast.LENGTH_SHORT).show();
        }
    }
}
