package com.example.weighttrackerniyatishetty;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUserName, editTextPassword;
    private Button buttonLogin, buttonSignup;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        editTextUserName = findViewById(R.id.editTextUserName);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonSignup = findViewById(R.id.buttonSignUp);

        buttonLogin.setOnClickListener(v->{
            String userName = editTextUserName.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            if (userName.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,"Please fill in username and password fields",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            Log.d("MainActivity", "Login button Clicked");
            Log.d("MainActivity", "Username: " + userName + " Password: " + password);

            boolean success = dbHelper.loginUser(userName,password);
            if (success) {
                Toast.makeText(this, "Login Successful!!!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                intent.putExtra("username", userName);
                startActivity(intent);
                finish();
            }
            else
            {
                Toast.makeText(this, "Invalid username and password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        buttonSignup.setOnClickListener(v-> {
            String userName = editTextUserName.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            if (userName.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,"Please fill in username and password fields",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean alreadyRegistered = dbHelper.registerUser(userName, password);
            if (alreadyRegistered) {
                Toast.makeText(this, "Registration Successful!!!. Please Log in",
                        Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(this, "User Name already exists",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}

